from django.urls import path
from . import views

urlpatterns = [ #Use kwargs when finding the url path in runserver
    path('', views.list_projects, name="projects"),
    path('project/<str:pk>/', views.relationship_queries, name='project')
]