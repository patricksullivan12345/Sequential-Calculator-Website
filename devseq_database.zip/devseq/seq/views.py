from django.shortcuts import render
from django.http import HttpResponse
from .models import projects, fiber, sequentials, tags
import numpy as np

"""
projectsList = [
    
    {
        'id':'1',
        'title':'Ecommerce Website',
        'description': 'Fully functional ecommerce website'
    },
    {
        'id':'2',
        'title':'Portfolio Website',
        'description': 'My portfolio website'
    },
    {
        'id':'3',
        'title':'Social Network',
        'description': 'Awesome open source project I am still working on'
    },

]
"""

def list_projects(request):
    names = projects.objects.all()
    fiber_names = fiber.objects.all()
    return render(request, 'seq/projects.html', {'names':names, 'fiber_names': fiber_names})

def relationship_queries(request, pk): #Projects kwargs must match!

    projectObj = projects.objects.get(id=pk)
    fib_query = fiber.objects.filter(project_relationship=str(projectObj.id))
    seq_query = sequentials.objects.select_related('fiber_relationship').filter(fiber_relationship__in=fib_query) 

    in_seqs =  np.array(seq_query.values_list('in_seq', flat=True))
    out_seqs =  np.array(seq_query.values_list('out_seq', flat=True))

    seqs = np.concatenate((in_seqs,out_seqs))
    seqs.sort()

    slack = np.subtract(out_seqs,in_seqs)
    slack = np.absolute(slack)

    in_seqs_wall = np.delete(in_seqs, [0])
    out_seqs_wall = np.delete(out_seqs, [len(out_seqs)-1])
    w2w = np.subtract(out_seqs_wall,in_seqs_wall)
    w2w = np.absolute(w2w)

    return render(request, 'seq/project.html', {'projectObj': projectObj, 'fib_query': fib_query, 'seq_query': seq_query, 'seqs': seqs, 'slack': slack, 'w2w': w2w})

#return HttpResponse("This return is working!")
