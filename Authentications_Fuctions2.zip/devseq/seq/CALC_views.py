from django.shortcuts import render
from .models import projects, fiber, sequentials
import numpy as np
import pandas as pd

def relationship_queries(request, pk): #Projects kwargs must match!

    projectObj = projects.objects.get(id=pk)
    fib_query = fiber.objects.filter(project_relationship=str(projectObj.id))
    seq_query = sequentials.objects.filter(fiber_relationship__in=fib_query).order_by('fiber_relationship') 
    all_seqs =  seq_query.values_list('fiber_relationship','in_seq','out_seq',).order_by('fiber_relationship')

    def master_dictionary(all_seqs):

        slack_list = []
        w2w_list = []
        measured_list = []
        seq_dict={}

        if len(all_seqs) != 0:

            if len(all_seqs) > 1:

                seq_df = pd.DataFrame(all_seqs)
            
                seq_in = np.array(seq_df.groupby(0)[1])
                seq_out = np.array(seq_df.groupby(0)[2])

                for i in range(len(seq_in)):

                    for seq in seq_in[i][1]:

                        seq_dict[seq_in[i][0]] =  [seq_in[i][1].tolist(),  seq_out[i][1].tolist()]

            elif len(all_seqs) <= 1: 

                slack_list.append(abs(all_seqs[0][1]-all_seqs[0][2]))
                w2w_list.append(0)
                measured_list.append("Measured length is: " + str(np.sum(slack_list)+np.sum(w2w_list)))

            for distance in seq_dict.values():

                if len(distance[0]) > 1: 

                    in_list = np.array(distance[0])
                    out_list = np.array(distance[1])

                    slack = np.concatenate([in_list,out_list])
                    slack_break = np.array_split(slack,2)

                    slack_diff = np.diff(slack_break, axis=0)

                    for slack_dist in slack_diff[0]:

                        slack_list.append(slack_dist)

                    w2w = np.delete(slack, 0)
                    w2w_final = np.delete(w2w, -1)
                    w2w_break = np.array_split(w2w_final,2)

                    w2w_diff = abs(w2w_break[0]-w2w_break[1])
                    w2w_diff = np.insert(w2w_diff, 0 , 0)

                    for w2w_dist in w2w_diff:
                        
                        w2w_list.append(w2w_dist)

                    measured_list.append("Measured length is: " + str(np.sum(slack_diff)+np.sum(w2w_diff)))

                else:

                    slack_list.append(abs(distance[0][0]-distance[1][0]))
                    w2w_list.append(0)
                    measured_list.append("Measured length is: " + str(np.sum(slack_list)+np.sum(w2w_list)))

            return slack_list,w2w_list,measured_list

        else:

            return '','',''
            

    measured_list = master_dictionary(all_seqs)

    return render(request, 'seq/project.html', {'projectObj': projectObj, 
                                                'fib_query': fib_query, 
                                                'seq_query':seq_query,
                                                'slack':measured_list[0],
                                                'w2w':measured_list[1],
                                                'measured_list':measured_list[2],
                                               })