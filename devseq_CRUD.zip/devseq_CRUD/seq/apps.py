from django.apps import AppConfig


class SeqConfig(AppConfig):
    name = 'seq'
