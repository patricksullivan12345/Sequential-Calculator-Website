alert("This is from hello.js!");
const mydata = JSON.parse(document.getElementById('mydata').textContent);